package com.didhuuu.controlehoras

import android.app.*
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.content.*
import android.net.Uri
import android.view.*
import android.widget.*
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {

    data class Employee(var id: Long, var name: String, var salary: Double)
    data class DayScale(var enabled: Boolean = true, var e: String = "08:00", var x1: String = "12:00", var r1: String = "13:30", var x2: String = "17:30")
    data class PunchDay(var employeeId: Long, var employeeName: String, var date: String, var punches: MutableList<String> = MutableList(6) { "" })

    private val blue = Color.rgb(0, 92, 205)
    private val darkBlue = Color.rgb(13, 54, 105)
    private val green = Color.rgb(0, 170, 82)
    private val bg = Color.rgb(245, 248, 252)
    private val card = Color.WHITE
    private val text = Color.rgb(25, 35, 50)
    private val muted = Color.rgb(105, 115, 130)

    private lateinit var root: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout
    private var selectedTab = 0
    private var selectedEmployeeId = 0L

    private val prefs by lazy { getSharedPreferences("controle_horas", MODE_PRIVATE) }
    private val employees = mutableListOf<Employee>()
    private val records = mutableListOf<PunchDay>()
    private val scale = linkedMapOf<String, DayScale>()
    private val days = listOf("Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom")
    private val dayKeys = listOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY)
    private val money = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
    private val df = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
    private val iso = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadData()
        if (employees.isNotEmpty()) selectedEmployeeId = employees.first().id
        buildShell()
        showTab(0)
    }

    private fun loadData() {
        employees.clear()
        val ea = JSONArray(prefs.getString("employees", "[]"))
        for (i in 0 until ea.length()) {
            val o = ea.getJSONObject(i)
            employees += Employee(o.getLong("id"), o.getString("name"), o.getDouble("salary"))
        }
        records.clear()
        val ra = JSONArray(prefs.getString("records", "[]"))
        for (i in 0 until ra.length()) {
            val o = ra.getJSONObject(i)
            val p = MutableList(6) { j -> o.optString("p$j", "") }
            records += PunchDay(o.getLong("employeeId"), o.getString("employeeName"), o.getString("date"), p)
        }
        scale.clear()
        for (i in days.indices) {
            val def = if (i < 5) DayScale() else DayScale(false, "", "", "", "")
            val o = JSONObject(prefs.getString("scale_$i", JSONObject().put("enabled", def.enabled).put("e", def.e).put("x1", def.x1).put("r1", def.r1).put("x2", def.x2).toString()))
            scale[days[i]] = DayScale(o.optBoolean("enabled", def.enabled), o.optString("e", def.e), o.optString("x1", def.x1), o.optString("r1", def.r1), o.optString("x2", def.x2))
        }
    }

    private fun saveData() {
        val ea = JSONArray()
        employees.forEach { ea.put(JSONObject().put("id", it.id).put("name", it.name).put("salary", it.salary)) }
        prefs.edit().putString("employees", ea.toString()).apply()

        val ra = JSONArray()
        records.forEach { r ->
            val o = JSONObject().put("employeeId", r.employeeId).put("employeeName", r.employeeName).put("date", r.date)
            r.punches.forEachIndexed { j, v -> o.put("p$j", v) }
            ra.put(o)
        }
        val e = prefs.edit().putString("records", ra.toString())
        days.forEachIndexed { i, d ->
            val s = scale[d]!!
            e.putString("scale_$i", JSONObject().put("enabled", s.enabled).put("e", s.e).put("x1", s.x1).put("r1", s.r1).put("x2", s.x2).toString())
        }
        e.apply()
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(10), dp(14), dp(10))
            background(blue, 0, 0, 0, 0)
        }
        val clock = TextView(this).apply { text = "◷"; textSize = 34f; setTextColor(Color.WHITE) }
        val title = TextView(this).apply {
            text = "  CONTROLE DE HORAS"
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, dp(62), 1f)
            gravity = Gravity.CENTER_VERTICAL
        }
        val settings = TextView(this).apply {
            text = "⚙"
            textSize = 28f
            setTextColor(Color.WHITE)
            setPadding(dp(8), 0, 0, 0)
            setOnClickListener { showSettings() }
        }
        header.addView(clock, LinearLayout.LayoutParams(dp(42), dp(62)))
        header.addView(title)
        header.addView(settings, LinearLayout.LayoutParams(dp(45), dp(62)))
        root.addView(header)

        content = FrameLayout(this).apply { setBackgroundColor(bg) }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2), dp(5), dp(2), dp(5))
            background(Color.WHITE, dp(18), 0, 0, 0)
        }
        val labels = listOf("⌂\nPonto", "▣\nHistórico", "▥\nRelatório", "♟\nFuncionários", "▦\nEscala")
        labels.forEachIndexed { i, label ->
            val b = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 12f
                setTypeface(null, Typeface.BOLD)
                setPadding(0, dp(5), 0, dp(4))
                setOnClickListener { showTab(i) }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(68), 1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun showTab(tab: Int) {
        selectedTab = tab
        content.removeAllViews()
        when (tab) {
            0 -> showPunch()
            1 -> showHistory()
            2 -> showReport()
            3 -> showEmployees()
            4 -> showScale()
        }
        for (i in 0 until nav.childCount) {
            val v = nav.getChildAt(i) as TextView
            if (i == tab) {
                v.setTextColor(blue)
                v.background(0xFFE7F0FF.toInt(), dp(16), dp(16), dp(16), dp(16))
            } else {
                v.setTextColor(muted)
                v.setBackgroundColor(Color.TRANSPARENT)
            }
        }
    }

    private fun page(title: String): LinearLayout {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(22))
        }
        val h = TextView(this).apply {
            text = title
            textSize = 25f
            setTypeface(null, Typeface.BOLD)
            setTextColor(darkBlue)
            setPadding(0, 0, 0, dp(14))
        }
        box.addView(h)
        scroll.addView(box)
        content.addView(scroll)
        return box
    }

    private fun showPunch() {
        val box = page("Bater Ponto")
        if (employees.isEmpty()) {
            box.addView(infoCard("Nenhum funcionário cadastrado.\nCadastre o primeiro em Funcionários."))
            return
        }
        val emp = employees.firstOrNull { it.id == selectedEmployeeId } ?: employees.first().also { selectedEmployeeId = it.id }
        box.addView(card().apply {
            val line = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)) }
            line.addView(label("Funcionário"))
            val spinner = Spinner(context)
            val names = employees.map { it.name }
            spinner.adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, names)
            spinner.setSelection(employees.indexOfFirst { it.id == selectedEmployeeId }.coerceAtLeast(0))
            spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    if (employees[pos].id != selectedEmployeeId) { selectedEmployeeId = employees[pos].id; showPunch() }
                }
            }
            line.addView(spinner)
            val sal = TextView(context).apply { text = "Salário mensal   ${money.format(emp.salary)}"; textSize = 14f; setTextColor(muted); setPadding(0, dp(8), 0, 0) }
            line.addView(sal)
            addView(line)
        }, 0, 0, 0, dp(10))

        box.addView(card().apply {
            val line = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(10), dp(16), dp(10)) }
            line.addView(TextView(context).apply { text = "▣"; textSize = 28f; setTextColor(blue) }, LinearLayout.LayoutParams(dp(42), dp(50)))
            line.addView(TextView(context).apply { text = "Hoje\n${df.format(Date())}"; textSize = 16f; setTextColor(text); setTypeface(null, Typeface.BOLD) }, LinearLayout.LayoutParams(0, dp(60), 1f))
            addView(line)
        }, 0, 0, 0, dp(12))

        val rec = getRecord(emp.id, today())
        val next = rec.punches.indexOfFirst { it.isBlank() }
        val action = Button(this).apply {
            text = if (next < 0) "PONTO DO DIA COMPLETO" else "▶  REGISTRAR PRÓXIMA BATIDA\n${punchNames[next]}"
            textSize = 15f
            setTextColor(Color.WHITE)
            isAllCaps = false
            background(green, dp(12), dp(12), dp(12), dp(12))
            isEnabled = next >= 0
            setOnClickListener {
                val r = getRecord(emp.id, today())
                val n = r.punches.indexOfFirst { it.isBlank() }
                if (n >= 0) {
                    r.punches[n] = nowTime()
                    saveData()
                    showPunch()
                }
            }
        }
        box.addView(action, LinearLayout.LayoutParams(-1, dp(72)).apply { bottomMargin = dp(12) })

        val names = punchNames
        names.forEachIndexed { i, n ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(4), dp(10), dp(4))
                background(Color.WHITE, dp(12), dp(12), dp(12), dp(12))
                elevation = dp(1).toFloat()
            }
            row.addView(TextView(this).apply { text = "${i + 1}"; textSize = 16f; gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD); background(0xFFEAF0F7.toInt(), 30, 30, 30, 30) }, LinearLayout.LayoutParams(dp(42), dp(42)))
            row.addView(TextView(this).apply { text = n; textSize = 15f; setTextColor(text); setPadding(dp(12), 0, 0, 0) }, LinearLayout.LayoutParams(0, dp(52), 1f))
            row.addView(TextView(this).apply { text = rec.punches[i].ifBlank { "--:--" }; textSize = 15f; setTextColor(if (rec.punches[i].isBlank()) muted else darkBlue); setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER })
            row.setOnClickListener { editPunch(rec, i) }
            box.addView(row, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(7) })
        }

        val calc = calculate(rec)
        val cards = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        cards.addView(metricCard("Horas trabalhadas", formatMin(calc.worked), blue), LinearLayout.LayoutParams(0, dp(82), 1f).apply { rightMargin = dp(6) })
        cards.addView(metricCard("Horas extras", formatMin(calc.extra60 + calc.extra100), green), LinearLayout.LayoutParams(0, dp(82), 1f).apply { leftMargin = dp(6) })
        box.addView(cards)
    }

    private val punchNames = listOf("Entrada", "Saída intervalo 1", "Retorno intervalo 1", "Saída intervalo 2", "Retorno intervalo 2", "Saída")

    private fun showHistory() {
        val box = page("Histórico de Pontos")
        if (employees.isEmpty()) { box.addView(infoCard("Cadastre um funcionário para começar.")); return }
        val emp = employees.firstOrNull { it.id == selectedEmployeeId } ?: employees.first()
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, employees.map { it.name })
        spinner.setSelection(employees.indexOfFirst { it.id == emp.id }.coerceAtLeast(0))
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (employees[pos].id != selectedEmployeeId) { selectedEmployeeId = employees[pos].id; showHistory() }
            }
        }
        head.addView(spinner, LinearLayout.LayoutParams(0, dp(55), 1f))
        val month = EditText(this).apply { hint = "Mês/ano"; setText(SimpleDateFormat("MM/yyyy", Locale("pt","BR")).format(Date())); setSingleLine() }
        head.addView(month, LinearLayout.LayoutParams(0, dp(55), 1f).apply { leftMargin = dp(8) })
        box.addView(head)

        val monthKey = SimpleDateFormat("MM/yyyy", Locale("pt","BR")).format(Date())
        val list = records.filter { it.employeeId == emp.id && it.date.endsWith(SimpleDateFormat("MM-yyyy", Locale.US).format(Date())) }.sortedByDescending { it.date }
        val total = list.sumOf { calculate(it).worked }
        val extra = list.sumOf { calculate(it).extra60 + calculate(it).extra100 }
        val metrics = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        metrics.addView(metricCard("Total de horas", formatMin(total), blue), LinearLayout.LayoutParams(0, dp(82), 1f).apply { rightMargin = dp(6) })
        metrics.addView(metricCard("Horas extras", formatMin(extra), green), LinearLayout.LayoutParams(0, dp(82), 1f).apply { leftMargin = dp(6) })
        box.addView(metrics)

        list.forEach { r ->
            val c = calculate(r)
            val date = parseIso(r.date)
            val title = SimpleDateFormat("dd", Locale.US).format(date)
            val dow = SimpleDateFormat("EEE", Locale("pt","BR")).format(date).uppercase()
            val row = card()
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)) }
            line.addView(TextView(this).apply { text = "$title\n$dow"; gravity = Gravity.CENTER; textSize = 13f; setTypeface(null, Typeface.BOLD); background(0xFFF0F4F8.toInt(), 12,12,12,12) }, LinearLayout.LayoutParams(dp(55), dp(58)))
            line.addView(TextView(this).apply { text = "${r.punches.getOrNull(0).orEmpty()} - ${r.punches.getOrNull(1).orEmpty()}    ${r.punches.getOrNull(2).orEmpty()} - ${r.punches.getOrNull(5).orEmpty()}\nTrabalhadas: ${formatMin(c.worked)}    Extras: ${formatMin(c.extra60+c.extra100)}"; textSize=13f; setTextColor(text); setPadding(dp(12),0,0,0) }, LinearLayout.LayoutParams(0, dp(70),1f))
            line.addView(TextView(this).apply { text="›"; textSize=28f; setTextColor(darkBlue) }, LinearLayout.LayoutParams(dp(30), dp(60)))
            row.addView(line)
            row.setOnClickListener { editRecord(r) }
            box.addView(row, LinearLayout.LayoutParams(-1, dp(86)).apply { bottomMargin = dp(8) })
        }
        if (list.isEmpty()) box.addView(infoCard("Nenhum registro neste mês."))
    }

    private fun showReport() {
        val box = page("Relatório Mensal")
        if (employees.isEmpty()) { box.addView(infoCard("Cadastre um funcionário para gerar o relatório.")); return }
        val emp = employees.firstOrNull { it.id == selectedEmployeeId } ?: employees.first()
        val list = records.filter { it.employeeId == emp.id && it.date.startsWith(SimpleDateFormat("yyyy-MM", Locale.US).format(Date())) }
        val worked = list.sumOf { calculate(it).worked }
        val e60 = list.sumOf { calculate(it).extra60 }
        val e100 = list.sumOf { calculate(it).extra100 }
        val hourly = emp.salary / 220.0
        val totalExtra = e60 / 60.0 * hourly * 1.60 + e100 / 60.0 * hourly * 2.00

        box.addView(infoCard("${emp.name}\nSalário: ${money.format(emp.salary)}\nValor hora: ${money.format(hourly)}\nHora extra 60%: ${money.format(hourly * 1.60)}\nHora extra 100%: ${money.format(hourly * 2.00)}"))
        val metrics = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        metrics.addView(metricCard("Trabalhadas", formatMin(worked), blue), LinearLayout.LayoutParams(0, dp(82), 1f).apply { rightMargin=dp(4) })
        metrics.addView(metricCard("Extra 60%", formatMin(e60), green), LinearLayout.LayoutParams(0, dp(82), 1f).apply { leftMargin=dp(4); rightMargin=dp(4) })
        metrics.addView(metricCard("Extra 100%", formatMin(e100), Color.rgb(245,140,20)), LinearLayout.LayoutParams(0, dp(82), 1f).apply { leftMargin=dp(4) })
        box.addView(metrics)
        box.addView(infoCard("Valor estimado das horas extras\n${money.format(totalExtra)}"))
        val pdf = Button(this).apply { text = "▧  GERAR PDF"; textSize=15f; setTextColor(Color.WHITE); background(blue,12,12,12,12); setOnClickListener { sharePdf(emp, list) } }
        box.addView(pdf, LinearLayout.LayoutParams(-1, dp(60)))
    }

    private fun showEmployees() {
        val box = page("Funcionários")
        employees.forEach { emp ->
            val row = card()
            val line = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(12),dp(8),dp(8),dp(8)) }
            line.addView(TextView(this).apply { text="●"; textSize=28f; setTextColor(blue); gravity=Gravity.CENTER }, LinearLayout.LayoutParams(dp(48),dp(62)))
            line.addView(TextView(this).apply { text="${emp.name}\n${money.format(emp.salary)}"; textSize=15f; setTextColor(text); setTypeface(null,Typeface.BOLD) }, LinearLayout.LayoutParams(0,dp(62),1f))
            val edit=TextView(this).apply { text="✎"; textSize=24f; setTextColor(blue); gravity=Gravity.CENTER; setOnClickListener { employeeDialog(emp) } }
            val del=TextView(this).apply { text="♜"; textSize=22f; setTextColor(Color.RED); gravity=Gravity.CENTER; setOnClickListener { confirmDelete(emp) } }
            line.addView(edit,LinearLayout.LayoutParams(dp(50),dp(62)))
            line.addView(del,LinearLayout.LayoutParams(dp(50),dp(62)))
            row.addView(line); box.addView(row,LinearLayout.LayoutParams(-1,dp(82)).apply{bottomMargin=dp(8)})
        }
        val add=Button(this).apply { text="＋  ADICIONAR FUNCIONÁRIO"; textSize=15f; setTextColor(Color.WHITE); background(blue,12,12,12,12); setOnClickListener{employeeDialog(null)} }
        box.addView(add,LinearLayout.LayoutParams(-1,dp(60)).apply{topMargin=dp(8)})
    }

    private fun showScale() {
        val box = page("Escala Semanal")
        box.addView(infoCard("Defina os dias trabalhados e os quatro horários da jornada. A escala é usada para calcular horas normais e extras."))
        days.forEachIndexed { i, d ->
            val s=scale[d]!!
            val row=card()
            val line=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(8),dp(12),dp(8))}
            val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            top.addView(TextView(this).apply{text=d;textSize=16f;setTypeface(null,Typeface.BOLD);setTextColor(darkBlue)},LinearLayout.LayoutParams(0,dp(48),1f))
            val sw=Switch(this).apply{text=if(s.enabled)"TRABALHA" else "FOLGA";isChecked=s.enabled;setOnCheckedChangeListener{_,v->s.enabled=v;text=if(v)"TRABALHA" else "FOLGA";saveData();showScale()}}
            top.addView(sw)
            line.addView(top)
            if(s.enabled){
                val times=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
                listOf("Entrada" to s.e,"Saída 1" to s.x1,"Retorno 1" to s.r1,"Saída 2" to s.x2).forEachIndexed{j,p->
                    val ed=EditText(this).apply{setText(p.second);hint="00:00";gravity=Gravity.CENTER;inputType=2;setSingleLine()}
                    ed.setOnFocusChangeListener{_,has->if(!has){when(j){0->s.e=ed.text.toString();1->s.x1=ed.text.toString();2->s.r1=ed.text.toString();3->s.x2=ed.text.toString()};saveData()}}
                    times.addView(ed,LinearLayout.LayoutParams(0,dp(55),1f).apply{if(j<3)rightMargin=dp(4)})
                }
                line.addView(times)
            }
            row.addView(line);box.addView(row,LinearLayout.LayoutParams(-1,if(s.enabled)dp(125) else dp(70)).apply{bottomMargin=dp(8)})
        }
    }

    private fun employeeDialog(existing: Employee?) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(4),dp(10),0)}
        val name=EditText(this).apply{hint="Nome";setText(existing?.name?:"");setSingleLine()}
        val salary=EditText(this).apply{hint="Salário mensal";setText(if(existing!=null)existing.salary.toString():"");inputType=2;setSingleLine()}
        box.addView(name);box.addView(salary)
        AlertDialog.Builder(this).setTitle(if(existing==null)"Novo funcionário" else "Editar funcionário").setView(box)
            .setNegativeButton("Cancelar",null).setPositiveButton("Salvar"){_,_->
                val n=name.text.toString().trim();val s=salary.text.toString().replace(",",".").toDoubleOrNull()?:0.0
                if(n.isNotBlank()&&s>0){if(existing==null)employees+=Employee(System.currentTimeMillis(),n,s) else {existing.name=n;existing.salary=s;records.filter{it.employeeId==existing.id}.forEach{it.employeeName=n}};saveData();showEmployees()}
            }.show()
    }

    private fun confirmDelete(emp:Employee){
        AlertDialog.Builder(this).setTitle("Excluir funcionário?").setMessage("O funcionário será removido da lista. Os registros históricos serão mantidos.")
            .setNegativeButton("Cancelar",null).setPositiveButton("Excluir"){_,_->employees.removeAll{it.id==emp.id};if(selectedEmployeeId==emp.id)selectedEmployeeId=employees.firstOrNull()?.id?:0L;saveData();showEmployees()}.show()
    }

    private fun editPunch(r:PunchDay,index:Int){
        val e=EditText(this).apply{setText(r.punches[index]);hint="HH:mm";inputType=2;setSingleLine()}
        AlertDialog.Builder(this).setTitle(punchNames[index]).setMessage("Altere o horário se necessário.").setView(e)
            .setNegativeButton("Cancelar",null).setPositiveButton("Salvar"){_,_->r.punches[index]=e.text.toString();saveData();showPunch()}.show()
    }

    private fun editRecord(r:PunchDay){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val fields=r.punches.mapIndexed{i,v->EditText(this).apply{hint=punchNames[i];setText(v);inputType=2;setSingleLine();}}
        fields.forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("Editar ponto").setView(box).setNegativeButton("Cancelar",null).setPositiveButton("Salvar"){_,_->fields.forEachIndexed{i,e->r.punches[i]=e.text.toString()};saveData();showHistory()}.show()
    }

    private fun showSettings(){
        AlertDialog.Builder(this).setTitle("Configurações").setMessage("Jornada de referência: 44 horas semanais / 220 horas mensais.\nHora extra 60% = hora × 1,60.\nHora extra 100% = hora × 2,00.\n\nEsses valores são usados nos relatórios.")
            .setPositiveButton("OK",null).show()
    }

    private fun getRecord(empId:Long,date:String):PunchDay{
        return records.firstOrNull{it.employeeId==empId&&it.date==date} ?: PunchDay(empId,employees.firstOrNull{it.id==empId}?.name?:"",date).also{records+=it}
    }

    private fun today()=iso.format(Date())
    private fun nowTime()=SimpleDateFormat("HH:mm",Locale.US).format(Date())

    data class Calc(val worked:Int,val expected:Int,val extra60:Int,val extra100:Int)

    private fun calculate(r:PunchDay):Calc{
        val worked=minutesBetween(r.punches[0],r.punches[1])+minutesBetween(r.punches[2],r.punches[3])+minutesBetween(r.punches[4],r.punches[5])
        val cal=Calendar.getInstance().apply{time=parseIso(r.date)}
        val key=cal.get(Calendar.DAY_OF_WEEK)
        val d=scale[days[dayKeys.indexOf(key).coerceAtLeast(0)]] ?: DayScale()
        val expected=minutesBetween(d.e,d.x1)+minutesBetween(d.r1,d.x2)
        return if(!d.enabled) Calc(worked,0,0,worked) else Calc(worked,expected,max(0,worked-expected),0)
    }

    private fun minutesBetween(a:String,b:String):Int{
        if(a.isBlank()||b.isBlank())return 0
        return try{val x=a.split(":");val y=b.split(":");max(0,(y[0].toInt()*60+y[1].toInt())-(x[0].toInt()*60+x[1].toInt()))}catch(_:Exception){0}
    }

    private fun formatMin(m:Int):String="${m/60}:%02d".format(m%60)

    private fun parseIso(s:String):Date=try{iso.parse(s)!!}catch(_:Exception){Date()}

    private fun sharePdf(emp:Employee, list:List<PunchDay>){
        val file=File(cacheDir,"relatorio_${emp.name.replace(" ","_")}_${SimpleDateFormat("yyyyMM",Locale.US).format(Date())}.pdf")
        val doc=android.graphics.pdf.PdfDocument()
        var pageNo=1;var y=40f
        var page=doc.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,pageNo).create())
        var c=page.canvas
        val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=14f}
        fun line(t:String){if(y>800){doc.finishPage(page);pageNo++;page=doc.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,pageNo).create());c=page.canvas;y=40f};c.drawText(t,35f,y,p);y+=24}
        p.textSize=20f;p.typeface=Typeface.DEFAULT_BOLD;line("CONTROLE DE HORAS - RELATÓRIO MENSAL")
        p.textSize=14f;p.typeface=Typeface.DEFAULT;line("Funcionário: ${emp.name}");line("Salário: ${money.format(emp.salary)}");line("")
        list.sortedBy{it.date}.forEach{r->val z=calculate(r);line("${df.format(parseIso(r.date))}  ${r.punches.joinToString("  ")}  Trabalhadas ${formatMin(z.worked)}  Extras ${formatMin(z.extra60+z.extra100)}")}
        doc.finishPage(page);file.outputStream().use{doc.writeTo(it)};doc.close()
        val uri=FileProvider.getUriForFile(this,"$packageName.fileprovider",file)
        val send=Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)}
        startActivity(Intent.createChooser(send,"Enviar relatório"))
    }

    private fun metricCard(title:String,value:String,color:Int):View{
        val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(7),dp(8),dp(7));background(if(color==green)0xFFE7F8EE.toInt() else 0xFFEAF2FF.toInt(),14,14,14,14)}
        l.addView(TextView(this).apply{text=title;textSize=12f;setTextColor(darkBlue)})
        l.addView(TextView(this).apply{text=value;textSize=19f;setTypeface(null,Typeface.BOLD);setTextColor(if(color==green)Color.rgb(0,120,55) else darkBlue)})
        return l
    }

    private fun infoCard(s:String):View=card().apply{val t=TextView(context).apply{text=s;textSize=14f;setTextColor(text);setPadding(dp(14),dp(14),dp(14),dp(14))};addView(t)}

    private fun card():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background(Color.WHITE,14,14,14,14);elevation=dp(1).toFloat()}

    private fun label(s:String)=TextView(this).apply{text=s;textSize=13f;setTextColor(muted);setTypeface(null,Typeface.BOLD)}

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt().coerceAtLeast(1)

    private fun View.background(color:Int,tl:Int,tr:Int,br:Int,bl:Int){
        background=GradientDrawable().apply{setColor(color);cornerRadii=floatArrayOf(dp(tl).toFloat(),dp(tl).toFloat(),dp(tr).toFloat(),dp(tr).toFloat(),dp(br).toFloat(),dp(br).toFloat(),dp(bl).toFloat(),dp(bl).toFloat())}
    }
}
