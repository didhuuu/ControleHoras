# ControleHoras

Aplicativo Android de controle de jornada com 6 batidas, cadastro de funcionários, escala semanal, histórico, relatório mensal, cálculo de horas extras e geração/compartilhamento de PDF.

Referência de jornada: 44 horas semanais / 220 horas mensais.
Hora normal = salário / 220.
Hora extra 60% = hora normal x 1,60.
Hora extra 100% = hora normal x 2,00.
